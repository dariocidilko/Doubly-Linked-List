
This is how to run the code for the test that I made (Oxford Dictionary Frequency):

1. (make) or (make all)
2. (./bin/debug/wordfrequency data/oxford_dictionary.txt x y z)

x = How many times a word appears.
y = How many characters do you want the words to consist of.
z = How many results do you want as a max.

Example usage is: (./bin/debug/wordfrequency data/oxford_dictionary.txt 100 5 50)